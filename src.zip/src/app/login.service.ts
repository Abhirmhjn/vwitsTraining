import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from './register/User';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private myHttp:HttpClient) { }

  loginUserService(loginUser:User)
  {
    console.log('LoginUser() invoked...');
    return this.myHttp.post<boolean>("http://localhost:8080/airline/login",loginUser);
  }
}
