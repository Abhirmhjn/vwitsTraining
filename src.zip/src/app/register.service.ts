import { Injectable, Optional } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './register/User';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private myHttp:HttpClient) { }

  public registerUserService(newUser:User):Observable<boolean> 
  {
    console.log('registerUser() invoked...');
    return this.myHttp.post<boolean>("http://localhost:8080/airline/register",newUser);
  }
}
