export class User
{
    title:string ="";
    name:string="";
    email:string ="";
    password:string ="";
    confirmpassword:string ="";
    gender:string="";
    dob:string="";
    phoneno:string="";
    
}