import { Component, OnInit, Optional } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { User } from './User';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  newUser=new User();
  isSuccessful:boolean |undefined;


  constructor(private service:RegisterService,private router:Router) { }

  ngOnInit(): void {
  }

  public registerUser()
  {
    console.log(JSON.stringify(this.newUser));
    this.service.registerUserService(this.newUser).subscribe(
      (result)=>{
        this.isSuccessful=result;
        console.log(this.newUser);
        console.log(this.isSuccessful);
        if(this.isSuccessful)
    {
      alert("User has been Successfully Registered ... Now Move to Login.");
      this.router.navigate(['login']);
    }
    else
    {
      alert("User Registeraion Unsuccessful ...Email should be unique");
      
    }
    
      },
      (err)=>{
        console.log(err);
      }
    );
    }
}
