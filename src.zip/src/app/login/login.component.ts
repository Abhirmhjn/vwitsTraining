import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { User } from '../register/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUser=new User();
  isLoginSuccessful:boolean | undefined;

  constructor(private service:LoginService,private router:Router) { }

  ngOnInit(): void {
  }

  public loginuser()
  {
    console.log(JSON.stringify(this.loginUser));
    this.service.loginUserService(this.loginUser).subscribe(
      (result)=>{
        this.isLoginSuccessful=result;
        console.log(this.loginUser);
        console.log(this.isLoginSuccessful);
       
    if(this.isLoginSuccessful)
    {
      alert("User has been Successfully Logged In ... ");
      this.router.navigate(['booking']);
    }
    else
    {
      alert("User Login Unsuccessful ...Enter Correct credentials");
    }
    
      },
      (err)=>{
        console.log(err);
      }
    );
    
  }
}
