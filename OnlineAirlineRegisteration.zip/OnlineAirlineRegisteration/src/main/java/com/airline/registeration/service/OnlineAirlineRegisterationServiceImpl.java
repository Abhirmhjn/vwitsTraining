package com.airline.registeration.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.registeration.entity.User;
import com.airline.registeration.exception.UserNotRegisteredException;
import com.airline.registeration.repository.OnlineAirlineRegisterationRepository;

@Service
public class OnlineAirlineRegisterationServiceImpl implements OnlineAirlineRegisterationService {

	@Autowired
	OnlineAirlineRegisterationRepository repository;
	
	@Override
	public boolean addNewUserService(User newUser) {
	
		return repository.addNewUser(newUser);
		
	}

	@Override
	public boolean loginUserService(User loginUser) {
		
		return repository.loginUser(loginUser);
	}

	
	

}
