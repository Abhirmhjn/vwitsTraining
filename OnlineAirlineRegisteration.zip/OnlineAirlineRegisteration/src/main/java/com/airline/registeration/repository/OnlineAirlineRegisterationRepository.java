package com.airline.registeration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.airline.registeration.entity.User;

@Repository
public interface OnlineAirlineRegisterationRepository {

	public boolean addNewUser(User newUser);
	public boolean loginUser(User loginUser);
	
}
