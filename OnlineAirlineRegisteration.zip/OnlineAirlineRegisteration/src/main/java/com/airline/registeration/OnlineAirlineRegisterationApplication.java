package com.airline.registeration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineAirlineRegisterationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineAirlineRegisterationApplication.class, args);
		System.out.println("Online Airline Module Started....");
	}

}
