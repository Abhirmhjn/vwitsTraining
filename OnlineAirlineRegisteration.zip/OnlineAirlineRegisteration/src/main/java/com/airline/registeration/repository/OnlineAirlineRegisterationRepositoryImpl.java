package com.airline.registeration.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.airline.registeration.entity.User;

@Repository
public class OnlineAirlineRegisterationRepositoryImpl implements OnlineAirlineRegisterationRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	@Transactional
	public boolean addNewUser(User newUser) {
		
		User foundUser = entityManager.find(User.class, newUser.getEmail());
		if(foundUser==null)
		{
			entityManager.persist(newUser);
			return true;
		}
		
		return false;
	}

	@Override
	public boolean loginUser(User loginUser) {

		User userFound = entityManager.find(User.class,loginUser.getEmail());
		if( userFound!=null && userFound.getPassword().equals(loginUser.getPassword()))
		{
			System.out.println("Login Successful......");
			return true;
		}
		else
		{
			System.out.println("Login Failed......");
			return false;
			
		}
	}

}
