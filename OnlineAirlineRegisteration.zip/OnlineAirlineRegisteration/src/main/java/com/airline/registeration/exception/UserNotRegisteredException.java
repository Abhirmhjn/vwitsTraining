package com.airline.registeration.exception;

public class UserNotRegisteredException extends Exception {

	public UserNotRegisteredException(String message) {
		super(message);
	}

	
}
