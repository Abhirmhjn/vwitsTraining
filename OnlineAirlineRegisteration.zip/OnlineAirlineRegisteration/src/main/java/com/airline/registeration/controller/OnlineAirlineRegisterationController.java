package com.airline.registeration.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.registeration.entity.User;
import com.airline.registeration.exception.UserNotRegisteredException;
import com.airline.registeration.service.OnlineAirlineRegisterationService;

@CrossOrigin
@RestController
@RequestMapping("/airline")
public class OnlineAirlineRegisterationController {

	@Autowired
	OnlineAirlineRegisterationService service;
	
	@PostMapping("/register")
	public boolean registerUser(@RequestBody User newUser) 
	{
		System.out.println("Controller Call to register new User .....");
		return service.addNewUserService(newUser);
	}
	
	@PostMapping("/login")
	public boolean loginUser(@RequestBody User loginUser ) 
	{
		System.out.println("Controller Call to Login User .....");
		return service.loginUserService(loginUser);
		
	}
}
