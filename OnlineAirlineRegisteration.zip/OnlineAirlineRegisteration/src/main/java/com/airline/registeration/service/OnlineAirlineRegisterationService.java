package com.airline.registeration.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.airline.registeration.entity.User;
import com.airline.registeration.exception.UserNotRegisteredException;

@Service
public interface OnlineAirlineRegisterationService {

	public boolean addNewUserService(User newUser) ;
	public boolean loginUserService(User loginUser) ;
}
