package com.airline.registeration.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User implements Serializable{

	
	
	private String title;
	private String name;
	@Id
	private String email;
	private String gender;
	private String password;
	public String getConfirmpassword() {
		return confirmpassword;
	}



	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}



	public String getPhoneno() {
		return phoneno;
	}



	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}


	private String confirmpassword;
	
	private LocalDate dob;
	
	private String phoneno;
	
	
	public User() {
		super();
	}



	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConfirmPassword() {
		return confirmpassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmpassword = confirmPassword;
	}


	public LocalDate getDob() {
		return dob;
	}


	public void setDob(LocalDate dob) {
		this.dob = dob;
	}


	public String getPhoneNo() {
		return phoneno;
	}


	public void setPhoneNo(String phoneno) {
		this.phoneno = phoneno;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "User [title=" + title + ", name=" + name + ", email=" + email + ", gender=" + gender + ", password="
				+ password + ", dob=" + dob +
				", phoneNo=" + phoneno + "]";
	}


	
	
	
}
